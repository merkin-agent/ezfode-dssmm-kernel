DS Style kernel audit patches (held set, posted on request)

Current repository: https://github.com/voluptuary/ezfode-dssmm-kernel

Base: origin/codespace at commit 83e350d (voluptuary/ezfode-dssmm-kernel, branch 'codespace').
Apply in a clean checkout of that commit, in this order:

    git checkout 83e350d
    git am patches/*.patch

Verified to apply cleanly to that base. Nothing here has been built with devkitARM or run on hardware: the sandbox used
an equivalent arm-none-eabi-gcc 13.2.1. The ledger files say what was proven (host tests, differential tests,
object-code comparisons) and what still needs a hardware test (the -Os build, see KERNEL_AUDIT_HANDOFF.md).
Some patches only update the ledger files (`KERNEL_AUDIT_*.md`); the others are firmware, build, test or tooling.

Contents, in apply order:
   1. 0001-Add-static-stack-depth-analysis-script-for-the-firmw.patch
      Add static stack-depth analysis script for the firmware  (source commit 7ce1b43)
   2. 0002-Remove-the-oversized-image-when-the-2-MiB-guard-fail.patch
      Remove the oversized image when the 2 MiB guard fails (CL-09)  (source commit 0908f23)
   3. 0003-Record-2026-10-17-verification-of-v7.4.6-CL-09-and-c.patch
      Record 2026-10-17 verification of v7.4.6, CL-09 and corrections in the ledgers  (source commit 4291e96)
   4. 0004-Record-settings-store-trace-and-retract-the-overflow.patch
      Record settings-store trace and retract the overflow lead in the ledgers  (source commit e4343cc)
   5. 0005-Skip-flash-rewrites-of-info-records-whose-content-is.patch
      Skip flash rewrites of info records whose content is unchanged (CL-08)  (source commit 6ef1e8d)
   6. 0006-Record-codespace-branch-review-rollback-verification.patch
      Record codespace-branch review, rollback verification and CL-08 rebuild in the ledgers  (source commit e1d36a7)
   7. 0007-Record-diagnostics-logger-proposal-size-performance-.patch
      Record diagnostics-logger proposal, size/performance study and fork comparison in the ledgers  (source commit 42b2216)
   8. 0008-Record-owner-decisions-header-proof-lossless-proof-a.patch
      Record owner decisions, header proof, lossless proof and speed-protected -Os plan in the ledgers  (source commit 454c817)
   9. 0009-Build-for-size-Os-with-speed-and-timing-sensitive-co.patch
      Build for size (-Os) with speed- and timing-sensitive code kept at -O  (source commit 28274d0)
  10. 0010-Remove-19-unreferenced-functions-from-ezkernelnew.c-.patch
      Remove 19 unreferenced functions from ezkernelnew.c (595 lines)  (source commit b09fb5d)
  11. 0011-Move-the-test-only-NOR-catalog-recovery-model-from-s.patch
      Move the test-only NOR catalog recovery model from source/ to tests/  (source commit ed1c953)
  12. 0012-Record-consolidation-stages-1-and-2-and-the-plan-for.patch
      Record consolidation stages 1 and 2 and the plan for the remaining stages in the ledgers  (source commit e53d328)
  13. 0013-Share-one-on-off-reader-for-the-five-boolean-setting.patch
      Share one on/off reader for the five boolean settings  (source commit 482e09a)
  14. 0014-Record-Stage-4a-shared-on-off-settings-reader-in-the.patch
      Record Stage 4a (shared on/off settings reader) in the ledgers  (source commit e3a8079)
  15. 0015-Drive-the-seven-enum-settings-readers-from-constant-.patch
      Drive the seven enum settings readers from constant tables  (source commit 6096f2e)
  16. 0016-Record-Stage-4b-and-a-consolidated-status-report-in-.patch
      Record Stage 4b and a consolidated status report in the ledgers  (source commit 57fdff1)
  17. 0017-Record-sandbox-recovery-owner-decisions-and-the-artw.patch
      Record sandbox recovery, owner decisions and the artwork scan-overhead investigation in the ledgers  (source commit 507a410)

Open work is tracked in KERNEL_AUDIT_HANDOFF.md. The full set will be posted again when the audit is finished.
